/*
	[WS_GetAVI_Info.cpp]
*/

#ifndef ___WS_GETAVI_INFO_CPP
#define ___WS_GETAVI_INFO_CPP


struct WSF_AVI_HEADER {
	char pRIFF[12];
	char pFormat_Chunk[12];
	char pMain_Avi_Header[8];
	DWORD dwMicroSecPerFrame;
	DWORD dwMaxBytesPerSec;
	DWORD dwPaddingGranularity;
	DWORD dwFlags;
	DWORD dwTotalFrames;
	DWORD dwInitialFrames;
	DWORD dwStreams;
	DWORD dwSuggestedBufferSize;
	DWORD dwWidth;
	DWORD dwHeight;
	DWORD dwReserved[4];
};


// AVI����t�@�C���̏c���T�C�Y���擾����B
bool GetAviWH( char* pszMoviePath, DWORD* pdwWidth, DWORD* pdwHeight ){
	WSF_AVI_HEADER stAviHeader;
	FILE *fp;

	*pdwWidth = 0;
	*pdwHeight = 0;
	if ((fp = fopen(pszMoviePath , "r")) != NULL) {
		fgets( (char*)&stAviHeader, sizeof(WSF_AVI_HEADER), fp );
		fclose( fp );

		if( 0==memcmp( stAviHeader.pRIFF + 8, "AVI ", 4 ) ){
			*pdwWidth = stAviHeader.dwWidth;
			*pdwHeight = stAviHeader.dwHeight;
			return true;
		}else{
			return false;
		}
	}else{
		return false;
	}
}


#endif

