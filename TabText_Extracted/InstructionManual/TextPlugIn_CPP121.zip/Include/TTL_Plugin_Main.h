/*
	[TTL_Plugin_Main.h]
	�֐��̐錾
	���肽�ԃ��� �̃v���O�C������̎���
*/

#ifndef ___ttl_plugin_dll_main_h
#define ___ttl_plugin_dll_main_h

#include "TTL_Plugin_Dll_Type.h"


bool Menu1_Title( int*, char* );
unsigned int Menu1_Work( HANDLE, char**, char**, HWND, char*, char*, char*, TtlExpand* );

bool Menu2_Title( int*, char* );
unsigned int Menu2_Work( HANDLE, char**, char**, HWND, char*, char*, char*, TtlExpand* );

bool Menu3_Title( int*, char* );
unsigned int Menu3_Work( HANDLE, char**, char**, HWND, char*, char*, char*, TtlExpand* );

bool Menu4_Title( int*, char* );
unsigned int Menu4_Work( HANDLE, char**, char**, HWND, char*, char*, char*, TtlExpand* );

bool Menu5_Title( int*, char* );
unsigned int Menu5_Work( HANDLE, char**, char**, HWND, char*, char*, char*, TtlExpand* );


#endif



