/*
	[TTL_Plugin_Dll_IF.cpp]
	���肽�ԃ��� �̃v���O�C��I/F�̎���
*/

#include <stdio.h>
#include <windows.h>
#include "..\Include\TTL_Plugin_Main.h"
#include "..\Include\TTL_Plugin_Dll_IF.h"


//�v���O�C���̌Ăяo�����Ǘ�����\���́B
struct DllItemDist {
	HANDLE hHeap;
	unsigned int nIndex;
	char* pNText;
	char* pNSel;
};



//�v���O�C���̌��Ɩ��O��I/F���Ǘ�
DLL_EXPORT int __stdcall TtlPlgIn_GetTMenuTitle( int nIndex, char* pszMenu ){
	int nRet = 0;
	int nItem;
	int nDummy = 0;

	switch (nIndex) {
	case -1:
		nItem = 0;
		if( Menu1_Title( &nDummy, NULL ) ){ nItem++; }
		if( Menu2_Title( &nDummy, NULL ) ){ nItem++; }
		if( Menu3_Title( &nDummy, NULL ) ){ nItem++; }
		if( Menu4_Title( &nDummy, NULL ) ){ nItem++; }
		if( Menu5_Title( &nDummy, NULL ) ){ nItem++; }
		nRet = nItem;
		break;

	case 0:
		Menu1_Title( &nRet, pszMenu );
		break;

	case 1:
		Menu2_Title( &nRet, pszMenu );
		break;

	case 2:
		Menu3_Title( &nRet, pszMenu );
		break;

	case 3:
		Menu4_Title( &nRet, pszMenu );
		break;
	case 4:
		Menu5_Title( &nRet, pszMenu );
		break;
	}

	return nRet;
}

//�v���O�C���̓���^�C�v��ԋp
DLL_EXPORT unsigned int __stdcall TtlPlgIn_GetActFlags( int nIndex ){
	TtlExpand stTtlEx;

	switch ( nIndex ) {
	case 0:
		Menu1_Work( NULL, NULL, NULL, NULL, NULL, NULL, NULL, &stTtlEx );
		break;
	case 1:
		Menu2_Work( NULL, NULL, NULL, NULL, NULL, NULL, NULL, &stTtlEx );
		break;
	case 2:
		Menu3_Work( NULL, NULL, NULL, NULL, NULL, NULL, NULL, &stTtlEx );
		break;
	case 3:
		Menu4_Work( NULL, NULL, NULL, NULL, NULL, NULL, NULL, &stTtlEx );
		break;
	case 4:
		Menu5_Work( NULL, NULL, NULL, NULL, NULL, NULL, NULL, &stTtlEx );
		break;
	}

	return stTtlEx.fFlags;
}

//�v���O�C���̊J�n���Ǘ�
DLL_EXPORT unsigned int __stdcall TtlPlgIn_HandleOpen( int nIndex ){
	DllItemDist* pst;
	HANDLE hHeap;

	hHeap = HeapCreate( 0, 0, 0 );
	pst = (DllItemDist*)HeapAlloc( hHeap, HEAP_ZERO_MEMORY, sizeof(DllItemDist) );
	pst->hHeap = hHeap;
	pst->nIndex = nIndex;

	return (unsigned int)pst;
}

//�v���O�C���̏I�����Ǘ�
DLL_EXPORT char __stdcall TtlPlgIn_HandleClose( unsigned int dwHandle ){
	DllItemDist* pst;
	HANDLE hHeap;

	pst = (DllItemDist*)dwHandle;
	hHeap = pst->hHeap;

	return (unsigned int)( HeapDestroy( hHeap ) );
}

//�v���O�C���̓����I/F���Ǘ�
DLL_EXPORT unsigned int __stdcall TtlPlgIn_Work( unsigned int dwHandle, unsigned int hWnd, char* pszFile, char* pszText, char* pszSel, char** ppzNText, char** ppzNSel, unsigned int dwReserved ){
	DllItemDist* pst;
	TtlExpand* pstTtlEx;
	TtlExpand stDmy_TtlEx;
	unsigned int nRet;

	pst = (DllItemDist*)dwHandle;
	if( dwReserved!=NULL ){
		pstTtlEx = (TtlExpand*)dwReserved;
	}else{
		stDmy_TtlEx.wVersion = 0;
		pstTtlEx = &stDmy_TtlEx;
	}

	switch (pst->nIndex) {
	case 0:
		nRet = Menu1_Work( pst->hHeap, &(pst->pNText), &(pst->pNSel), (HWND)hWnd, pszFile, pszText, pszSel, pstTtlEx );
		break;
	case 1:
		nRet = Menu2_Work( pst->hHeap, &(pst->pNText), &(pst->pNSel), (HWND)hWnd, pszFile, pszText, pszSel, pstTtlEx );
		break;
	case 2:
		nRet = Menu3_Work( pst->hHeap, &(pst->pNText), &(pst->pNSel), (HWND)hWnd, pszFile, pszText, pszSel, pstTtlEx );
		break;
	case 3:
		nRet = Menu4_Work( pst->hHeap, &(pst->pNText), &(pst->pNSel), (HWND)hWnd, pszFile, pszText, pszSel, pstTtlEx );
		break;
	case 4:
		nRet = Menu5_Work( pst->hHeap, &(pst->pNText), &(pst->pNSel), (HWND)hWnd, pszFile, pszText, pszSel, pstTtlEx );
		break;
	}

	switch (nRet) {
	case TTL_PLUGIN_ALLTEXT:
		*ppzNText = pst->pNText;
		break;

	case TTL_PLUGIN_SELECTED:
		*ppzNSel = pst->pNSel;
		break;
	}

	return nRet;
}






