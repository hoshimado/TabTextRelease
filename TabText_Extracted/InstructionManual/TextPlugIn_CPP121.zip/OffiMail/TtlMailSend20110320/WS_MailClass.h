/*
	[WS_MailClass.h]
	Author : Xing Yanhuan
*/


#include <winsock2.h>
#include <windowsx.h>


#include <iostream>
#include <string>
#include <stdio.h>



class Mail{
public:
	void setFrom(const std::string& from);
	void setTo(const std::string& to);
	void setSubject(const std::string& subject);
	void setBody(const std::string& body);
	std::string getFrom() const;
	std::string getTo() const;
	std::string getSubject() const;
	std::string getBody() const;
private:
	std::string from_;
	std::string to_;
	std::string subject_;
	std::string body_;
};






class MailTransporter{
public:
	MailTransporter();
	~MailTransporter();


	// SMTP�T�[�o�[��ݒ肷��B
	void setSmtp(const std::string& serverName);
	// Pop3�T�[�o�[�ƁA�F��ID�p�X���[�h��ݒ肷��B
	void setPop3(const std::string& serverName, const std::string& serverAccount, const std::string& serverPass);

	// ���[���𑗐M����B
	bool send(const Mail& mail);

	// �G���[�������̃��b�Z�[�W��Ԃ��B
	char* GetErrorMsg();

private:
	void sendMailMsg(SOCKET s, const std::string& text);
	void recvMailMsg(SOCKET s, char* pszRcvBuf, int nBufSize );
	bool PopBeforeSMTP();

	bool fWSAStartup;
	std::string strErrMsg;
	std::string smtp_;
	std::string pop3_;
	std::string accu_;
	std::string pass_;
};

